package com.statham.jason.oligarh;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Raspredelenie extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_raspredelenie);
    }
}
