package com.statham.jason.oligarh;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.UUID;

public class Friends extends AppCompatActivity {
    Button btn_Back;
    ImageView imageView7, imageView15;
    Button btn_Generate, button6, button7;
    EditText editText;
    DataBase dataBase;
    TextView textView38;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    public static final String APP_CODE_ONE = "CODE_ONE";
    public static final String APP_CODE_TWO = "CODE_TWO";
    public static final String APP_CODE_THREE = "CODE_THREE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);
        textView38 = (TextView) findViewById(R.id.textView38);
        dataBase = new DataBase(this);
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);
        imageView7 = (ImageView) findViewById(R.id.imageView7);
        imageView15 = (ImageView) findViewById(R.id.imageView15);
        btn_Back = (Button) findViewById(R.id.btn_Back);
        btn_Generate = (Button) findViewById(R.id.btn_Generate);
        editText = (EditText) findViewById(R.id.editText);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GenThree();
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GenTwo();
            }
        });
        btn_Generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Generate();
                Gen();
            }
        });
        btn_Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(Friends.this, MainMenu.class);
                startActivity(back);

            }
        });
        PushImage();
        textView38.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Test();
            }
        });
      //  GetCode();
    }

    public void PushImage() {
        int first = R.drawable.world_fri;
        int second = R.drawable.questions;

        Glide
                .with(this)
                .load(first)
                .into(imageView7);
        Glide
                .with(this)
                .load(second)
                .into(imageView15);
    }

    public void Generate() {

        String genor = generateString();
        editText.setText(genor);
    }

    public static String generateString() {
        String uuid = UUID.randomUUID().toString();
        return uuid;
    }

    public void onClick(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(Friends.this);
        builder.setTitle("Важное сообщение")
                .setMessage("Вам требуется нажать кнопку сгенерировать код и дать этот код другу(ваш друг должен скачать приложение и вставить этот код в пункт меню который называется ввести код), после этих действий вы получаете один балл на свой счет. ДАЙТЕ ДРУГУ НЕ ТОЛЬКО КОД НО И СВОЙ ПРЕФИКС (ПРЕФИКС ДОСТУПЕН В ЛИЧНОМ КАБИНЕТЕ)")
                .setIcon(R.drawable.dia_two)
                .setCancelable(false)
                .setNegativeButton("ОК,Закрыть",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }


    private void SafeData() {

        String codes = editText.getText().toString().trim();
        SafeUserData safeUserData = new SafeUserData(codes);
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        String end = "Codes_Cab_One/" + user.getUid();
        databaseReference.child(end).setValue(safeUserData);

        SharedPreferences pref;
        pref = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);;
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(APP_CODE_ONE, codes);
        editor.apply();

    }

    private void SafeDataTwo() {

        String codes = editText.getText().toString().trim();
        SafeUserData safeUserData = new SafeUserData(codes);
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        String end = "Codes_Cab_Two/" + user.getUid();
        databaseReference.child(end).setValue(safeUserData);
        /////////////////

        SharedPreferences pref;
        pref = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);;
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(APP_CODE_TWO, codes);
        editor.apply();

    }

    private void SafeDataThree() {

        String codes = editText.getText().toString().trim();
        SafeUserData safeUserData = new SafeUserData(codes);
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        String end = "Codes_Cab_Three/" + user.getUid();
        databaseReference.child(end).setValue(safeUserData);
        /////////////
        SharedPreferences pref;
        pref = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);;
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(APP_CODE_THREE, codes);
        editor.apply();

    }

    private void Test() {
        String test = editText.getText().toString();
        String fun = "mirko_hello_999";
        String drop_data ="mirko_hello_two_999";
        String ten = "mirko_add_coin_cheat_10";
        String fifty ="mirko_add_coin_cheat_50";
        String hundred ="mirko_add_coin_cheat_hundred";
        if(test.contains(hundred)==true){
            SharedPreferences pref;
            pref = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);;
            SharedPreferences.Editor editor = pref.edit();
            editor.putString("CASE_ONE", "100");
            editor.apply();
            Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show();
        }
        if(test.contains(fifty)==true){
            SharedPreferences pref;
            pref = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);;
            SharedPreferences.Editor editor = pref.edit();
            editor.putString("CASE_ONE", "50");
            editor.apply();
            Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show();
        }
        if(test.contains(ten)==true){
            SharedPreferences pref;
            pref = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);;
            SharedPreferences.Editor editor = pref.edit();
            editor.putString("CASE_ONE", "10");
            editor.apply();
            Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show();
        }
        if (test.contains(fun) == true) {
            String codes = "0";
            SafeUserData safeUserData = new SafeUserData(codes);
            FirebaseUser user = firebaseAuth.getCurrentUser();
            assert user != null;
            String end = "No_Drop/";
            databaseReference.child(end).child("Code").setValue(safeUserData);
            Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show();
        }
        if(test.contains(drop_data)){
            String codes ="0";
            databaseReference.child("No_Drop").child("Code").child("drop").setValue(codes);
            Toast.makeText(this, "OK", Toast.LENGTH_SHORT).show();
        }

    }

    public void Gen() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Friends.this);
        builder.setTitle("Генерация кода в Кейс 1 ")
                .setMessage("Повторная генерация кода уничтожит ранее сгенерированный код (если ваш друг не ввел код - вы не получите 1 монету и друг не сможет начать игру). Вы уверены что хотите сгенерировать код для нового друга?")
                .setIcon(R.drawable.dia_two)
                .setCancelable(false).setNegativeButton("Да,Генерируй",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Generate();
                        SafeData();

                    }
                })
                .setPositiveButton("Нет,Выход", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent cancel = new Intent(Friends.this, MainMenu.class);
                        startActivity(cancel);
                    }
                })
        ;

        AlertDialog alert = builder.create();
        alert.show();
    }

    public void GenTwo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Friends.this);
        builder.setTitle("Генерация кода в Кейс 2")
                .setMessage("Повторная генерация кода уничтожит ранее сгенерированный код (если ваш друг не ввел код - вы не получите 1 монету и друг не сможет начать игру). Вы уверены что хотите сгенерировать код для нового друга?")
                .setIcon(R.drawable.dia_two)
                .setCancelable(false).setNegativeButton("Да,Генерируй",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Generate();
                        SafeDataTwo();

                    }
                })
                .setPositiveButton("Нет,Выход", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent cancel = new Intent(Friends.this, MainMenu.class);
                        startActivity(cancel);
                    }
                })
        ;

        AlertDialog alert = builder.create();
        alert.show();
    }

    public void GenThree() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Friends.this);
        builder.setTitle("Генерация кода в Кейс 3")
                .setMessage("Повторная генерация кода уничтожит ранее сгенерированный код (если ваш друг не ввел код - вы не получите 1 монету и друг не сможет начать игру). Вы уверены что хотите сгенерировать код для нового друга?")
                .setIcon(R.drawable.dia_two)
                .setCancelable(false).setNegativeButton("Да,Генерируй",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Generate();
                        SafeDataThree();

                    }
                })
                .setPositiveButton("Нет,Выход", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent cancel = new Intent(Friends.this, MainMenu.class);
                        startActivity(cancel);
                    }
                })
        ;

        AlertDialog alert = builder.create();
        alert.show();
    }

   /* public void GetCode(){
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        String money = preferences.getString("CODE_THREE", "");
        textView38.setText(money);
    }*/
}
