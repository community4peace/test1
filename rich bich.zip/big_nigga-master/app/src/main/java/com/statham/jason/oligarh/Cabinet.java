package com.statham.jason.oligarh;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Cabinet extends AppCompatActivity {
    Button btn_Back;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    private TextView textView58, textView18, textView21;
    private TextView textView16, textView17, textView19;
    private TextView textView22, textView29;
    private Button button3;

    ImageView imageView7, imageView8, imageView9, imageView10, imageView11, imageView12, imageView13, imageView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cabinet);
        textView58 = (TextView) findViewById(R.id.textView58);
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        imageView7 = (ImageView) findViewById(R.id.imageView7);
        imageView8 = (ImageView) findViewById(R.id.imageView8);
        imageView9 = (ImageView) findViewById(R.id.imageView9);
        imageView10 = (ImageView) findViewById(R.id.imageView10);
        textView21 = (TextView) findViewById(R.id.textView21);
        textView17 = (TextView) findViewById(R.id.textView17);
        button3 = (Button) findViewById(R.id.button3);
        textView16 = (TextView) findViewById(R.id.textView16);
        textView18 = (TextView) findViewById(R.id.textView18);
        textView22 = (TextView) findViewById(R.id.textView22);
        imageView11 = (ImageView) findViewById(R.id.imageView11);
        textView19 = (TextView) findViewById(R.id.textView19);
        textView29 = (TextView) findViewById(R.id.textView29);
        imageView12 = (ImageView) findViewById(R.id.imageView12);
        imageView13 = (ImageView) findViewById(R.id.imageView13);
        imageView2 = (ImageView) findViewById(R.id.imageView2);
        PushImage();
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent go = new Intent(Cabinet.this, Card_D.class);
                startActivity(go);
            }
        });
        btn_Back = (Button) findViewById(R.id.btn_Back);
        btn_Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(Cabinet.this, MainMenu.class);
                startActivity(back);
            }
        });
        Pref();
        Three();
    }

    public void PushImage() {
        int first = R.drawable.users;
        int second = R.drawable.date;
        int third = R.drawable.people;
        int four = R.drawable.online;
        int five = R.drawable.balance;
        int six = R.drawable.dollars;
        int seven = R.drawable.bank;
        int eight = R.drawable.clip;
        Glide
                .with(this)
                .load(first)
                .into(imageView7);
        Glide
                .with(this)
                .load(second)
                .into(imageView8);
        Glide
                .with(this)
                .load(third)
                .into(imageView9);
        Glide
                .with(this)
                .load(four)
                .into(imageView10);
        Glide
                .with(this)
                .load(five)
                .into(imageView11);
        Glide
                .with(this)
                .load(six)
                .into(imageView12);
        Glide
                .with(this)
                .load(seven)
                .into(imageView13);
        Glide
                .with(this)
                .load(eight)
                .into(imageView2);
    }

    public void Pref() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        String end = user.getUid();
        textView58.setText(end);
    }


    private void Three() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        final String first = user.getUid();

        databaseReference.child("Users").child(first).child("name").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                String search = snapshot.getValue().toString();
                textView16.setText(search);
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });
        databaseReference.child("Users").child(first).child("surname").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                String search = snapshot.getValue().toString();
                textView17.setText(search);
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });


        String data = preferences.getString("CALENDAR", "");
        textView18.setText(data + " - перв. вход");
        String firs = preferences.getString("CASE_ONE", "");
        String second = preferences.getString("CASE_TWO", "");
        String third = preferences.getString("CASE_THREE", "");
        String saved_coins = preferences.getString("SAVED_COINS", "");
        int o = Integer.parseInt(firs);
        int t = Integer.parseInt(second);
        int th = Integer.parseInt(third);
        int res = o + t + th ;
        String ress = String.valueOf(res);
        textView19.setText(ress + " друзей");
        int coinss = res + 1;
        String coin = String.valueOf(coinss);
        textView21.setText(coin + " монет");
        int dollars = o + th;
        String dollar = String.valueOf(dollars);
        textView22.setText(dollar + " долларов");
        textView29.setText(saved_coins + " монет");

    }
}
