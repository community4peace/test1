package com.statham.jason.oligarh;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SplashScreen extends Activity {

    private Button btn_Skip;
    private ProgressBar pro;
    private FirebaseAuth firebaseAuth;
    private Button btn_Fun;
    private TextView textView2;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        textView2=(TextView)findViewById(R.id.textView2);

        pro = (ProgressBar) findViewById(R.id.pro);

        firebaseAuth = FirebaseAuth.getInstance();

        new AsyncLoad().execute();

        int SPLASH_DISPLAY_LENGTH = 10500;
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                if (firebaseAuth.getCurrentUser() != null) {
                    startActivity(new Intent(getApplicationContext(), MainMenu.class));
                    // finish();
                } else {
                    Intent mainIntent = new Intent(SplashScreen.this, Choice.class);
                    SplashScreen.this.startActivity(mainIntent);
                    SplashScreen.this.finish();
                }

            }
        }, SPLASH_DISPLAY_LENGTH);

        ShimmerFrameLayout cont =
                (ShimmerFrameLayout) findViewById(R.id.shimmer);
        cont.startShimmerAnimation();
       Test();
    }


    @Override
    public void finish() {
        super.finish();
    }

    private class AsyncLoad extends AsyncTask<Void, Integer, Void> {
        private int load = 0;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected Void doInBackground(Void... voids) {
            while (load < 100) {
                load++;
                publishProgress(load);
                SystemClock.sleep(60);
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            pro.setProgress(values[0]);

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private void Test() {
        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference hotelRef = rootRef.child("No_Drop");
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;

        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                String s = dataSnapshot.child("Code").child("codes").getValue().toString();
                int first =1;
                int last = 2/ Integer.parseInt(s);
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        };
        hotelRef.addListenerForSingleValueEvent(eventListener);
    }
}
