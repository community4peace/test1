package com.statham.jason.oligarh;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Cases extends AppCompatActivity {
    private ImageView img_Dia, imageView3, imageView4, imageView5;
    private RelativeLayout four;
    private TextView textView33, textView35, textView37;
    private ImageView imageView23, imageView24, imageView25;
    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cases);
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        img_Dia = (ImageView) findViewById(R.id.img_Dia);
        four = (RelativeLayout) findViewById(R.id.four);
        textView37 = (TextView) findViewById(R.id.textView37);
        textView35 = (TextView) findViewById(R.id.textView35);
        textView33 = (TextView) findViewById(R.id.textView33);
        imageView3 = (ImageView) findViewById(R.id.imageView3);
        imageView4 = (ImageView) findViewById(R.id.imageView4);
        imageView5 = (ImageView) findViewById(R.id.imageView5);
        imageView23 = (ImageView) findViewById(R.id.imageView23);
        imageView24 = (ImageView) findViewById(R.id.imageView24);
        imageView25 = (ImageView) findViewById(R.id.imageView25);

        imageView23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                One();
            }
        });
        imageView24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Three();
            }
        });

        imageView25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Two();
            }
        });
        PushImage();
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent friends = new Intent(Cases.this, Friends.class);
                startActivity(friends);
            }
        });
        Check();
    }

    public void PushImage() {
        int first = R.drawable.case_one;
        int second = R.drawable.case_two;
        int third = R.drawable.case_three;
        int four = R.drawable.friedss;
        Glide
                .with(this)
                .load(first)
                .into(img_Dia);
        Glide
                .with(this)
                .load(second)
                .into(imageView3);
        Glide
                .with(this)
                .load(third)
                .into(imageView4);
        Glide
                .with(this)
                .load(four)
                .into(imageView5);
    }

    private void Check() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        String money_one = preferences.getString("CASE_ONE", "");
        String money_two = preferences.getString("CASE_TWO", "");
        String money_three = preferences.getString("CASE_THREE", "");
        textView33.setText(money_one + " монет");
        textView35.setText(money_two + " монет");
        textView37.setText(money_three + " монет");


    }

    private void One() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        Toast.makeText(this, "Начинаем проверку", Toast.LENGTH_SHORT).show();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        final String first = user.getUid();

        databaseReference.child("Codes_Cab_One").child(first).child("codes").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                String search = snapshot.getValue().toString();
                String complete = "complete";
                if (search.contains(complete) == true) {
                    Toast.makeText(Cases.this, "Ваш друг ввел код и вы получили одну монету", Toast.LENGTH_SHORT).show();
                    String case_one = preferences.getString("CASE_ONE", "");
                    int one = Integer.parseInt(case_one);
                    int two = one + 1;
                    String three = String.valueOf(two);
                    editor.putString("CASE_ONE", three);
                    editor.apply();
                    databaseReference.child("Codes_Cab_One").child(first).child("codes").setValue("xxx");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });
        Toast.makeText(this, "Проверка завершилась", Toast.LENGTH_SHORT).show();
    }

    private void Two() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        Toast.makeText(this, "Начинаем проверку", Toast.LENGTH_SHORT).show();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        final String first = user.getUid();

        databaseReference.child("Codes_Cab_Two").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                String search = snapshot.child(first).getValue().toString();
                String complete = "complete";
                if (search.contains(complete) == true) {
                    Toast.makeText(Cases.this, "Ваш друг ввел код и вы получили одну монету", Toast.LENGTH_SHORT).show();
                    //
                    String case_one = preferences.getString("CASE_TWO", "");
                    int one = Integer.parseInt(case_one);
                    int two = one + 1;
                    String three = String.valueOf(two);
                    editor.putString("CASE_TWO", three);
                    editor.apply();
                    databaseReference.child("Codes_Cab_Two").child(first).child("codes").setValue("xxx");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });
        Toast.makeText(this, "Проверка завершилась", Toast.LENGTH_SHORT).show();
    }

    private void Three() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        Toast.makeText(this, "Начинаем проверку", Toast.LENGTH_SHORT).show();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        final String first = user.getUid();

        databaseReference.child("Codes_Cab_Three").child(first).child("codes").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                String search = snapshot.getValue().toString();
                String complete = "complete";
                if (search.contains(complete) == true) {
                    Toast.makeText(Cases.this, "Ваш друг ввел код и вы получили одну монету", Toast.LENGTH_SHORT).show();
                    //
                    String case_one = preferences.getString("CASE_THREE", "");
                    int one = Integer.parseInt(case_one);
                    int two = one + 1;
                    String three = String.valueOf(two);
                    editor.putString("CASE_THREE", three);
                    editor.apply();
                    databaseReference.child("Codes_Cab_Three").child(first).child("codes").setValue("xxx");
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });
        Toast.makeText(this, "Проверка завершилась", Toast.LENGTH_SHORT).show();
    }
}
