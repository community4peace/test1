package com.statham.jason.oligarh;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainMenu extends AppCompatActivity {
    private Button btn_Logout;
    private TextView text_Info;
    private RelativeLayout one, two, three, four, input;
    private ImageView img_Cabi, img_Casese, imageView4, imageView5, img_Key;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        three = (RelativeLayout) findViewById(R.id.three);
        four = (RelativeLayout) findViewById(R.id.four);
        img_Cabi = (ImageView) findViewById(R.id.img_Cabi);
        img_Casese = (ImageView) findViewById(R.id.img_Casese);
        imageView4 = (ImageView) findViewById(R.id.imageView4);
        text_Info = (TextView) findViewById(R.id.text_Info);
        imageView5 = (ImageView) findViewById(R.id.imageView5);
        img_Key = (ImageView) findViewById(R.id.img_Key);
        PushImage();
        btn_Logout = (Button) findViewById(R.id.btn_Logout);
        one = (RelativeLayout) findViewById(R.id.one);
        two = (RelativeLayout) findViewById(R.id.two);
        input = (RelativeLayout) findViewById(R.id.input);
        input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent input = new Intent(MainMenu.this, Input_Code.class);
                startActivity(input);
            }
        });
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cabinet = new Intent(MainMenu.this, Cabinet.class);
                startActivity(cabinet);
            }
        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cabinet = new Intent(MainMenu.this, Cases.class);
                startActivity(cabinet);
            }
        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent three = new Intent(MainMenu.this, Friends.class);
                startActivity(three);
            }
        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent four = new Intent(MainMenu.this, Reklama.class);
                startActivity(four);

            }
        });

        btn_Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getApplicationContext(),"Выполнен выход из аккаунта", Toast.LENGTH_LONG).show();
                //firebaseAuth.signOut();
                //finish();
                //startActivity(new Intent(MainMenu.this , Choice.class));
                ExitAccount();
            }
        });
        Three();
        Funny();
    }

    public void PushImage() {
        int first = R.drawable.cabn;
        int second = R.drawable.casese;
        int third = R.drawable.handsshake;
        int four = R.drawable.prize;
        int five = R.drawable.keyboard;

        Glide
                .with(this)
                .load(first)
                .into(img_Cabi);
        Glide
                .with(this)
                .load(second)
                .into(img_Casese);
        Glide
                .with(this)
                .load(third)
                .into(imageView4);
        Glide
                .with(this)
                .load(four)
                .into(imageView5);

        Glide
                .with(this)
                .load(five)
                .into(img_Key);
    }

    private void ExitAccount() {
        AlertDialog.Builder quitDialog = new AlertDialog.Builder(
                MainMenu.this);
        Resources res = getResources();
        String one = res.getString(R.string.exit_acc);
        String two = res.getString(R.string.yes_acc);
        String three = res.getString(R.string.no_acc);

        quitDialog.setTitle(one);

        quitDialog.setPositiveButton(two, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        firebaseAuth.signOut();
                        finish();
                        startActivity(new Intent(getApplicationContext(), Choice.class));

                        /*Intent exit = new Intent(MainPartActivity.this, MainActivity.class);
                        startActivity(exit);*/

                    }
                }
        );

        quitDialog.setNegativeButton(three, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(), R.string.continue_acc, Toast.LENGTH_SHORT).show();

            }
        });

        quitDialog.show();
    }


    private void Three() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        final String first = user.getUid();

        databaseReference.child("Users").child(first).child("name").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                String search = snapshot.getValue().toString();
                text_Info.setText("Здравствуйте , " + search);
            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });

    }

    private void Funny() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        final DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        final DatabaseReference hotelRef = rootRef.child("No_Drop");
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String prov = "0";
                    String codes = ds.child("drop").getValue(String.class);
                    if (codes.contains(prov) == true) {
                        SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.clear();
                        editor.commit();
                    }


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        };
        hotelRef.addListenerForSingleValueEvent(eventListener);
    }

}
