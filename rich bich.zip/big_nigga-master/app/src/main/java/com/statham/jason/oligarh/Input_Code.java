package com.statham.jason.oligarh;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Input_Code extends AppCompatActivity {
    private ImageView imageView7, imageView15;
    private Button btn_Back, btn_Generate;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    DataBase dataBase;
    private EditText editText, editText5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input__code);
        dataBase = new DataBase(this);
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        imageView7 = (ImageView) findViewById(R.id.imageView7);
        btn_Generate = (Button) findViewById(R.id.btn_Generate);
        editText = (EditText) findViewById(R.id.editText);
        editText5 = (EditText) findViewById(R.id.editText5);
        imageView15 = (ImageView) findViewById(R.id.imageView15);
        btn_Back = (Button) findViewById(R.id.btn_Back);
        btn_Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(Input_Code.this, MainMenu.class);
                startActivity(back);
            }
        });
        btn_Generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CodeInputOne();
                CodeInputTwo();
                CodeInputThree();
            }
        });
        PushImage();
    }

    public void PushImage() {
        int first = R.drawable.secure_zam;
        int second = R.drawable.questions;


        Glide
                .with(this)
                .load(first)
                .into(imageView7);
        Glide
                .with(this)
                .load(second)
                .into(imageView15);

    }

    public void onLock(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(Input_Code.this);
        builder.setTitle("Важное сообщение")
                .setMessage("Вам требуется ввести сюда код который вы получили от своего друга( вводите код и скорее присоединяйтесь к игре)")
                .setIcon(R.drawable.dia_two)
                .setCancelable(false)
                .setNegativeButton("ОК,Закрыть",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }


    public void CodeInputOne() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        Toast.makeText(this, "Ничего не делайте мы выполняем проверку", Toast.LENGTH_SHORT).show();
        final DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        final DatabaseReference hotelRef = rootRef.child("Codes_Cab_One");
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        final String prefics = editText5.getText().toString();
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String codes = ds.child("codes").getValue(String.class);
                    String stroka = editText.getText().toString();
                    if (codes.contains(stroka) == true) {
                        String money = preferences.getString("CASE_ONE", "");
                        int first = Integer.parseInt(money);
                        int last = first - 1;
                        String result = String.valueOf(last);
                        editor.putString("CASE_ONE", result);
                        editor.apply();
                        databaseReference.child("Codes_Cab_One").child(prefics).child("codes").setValue("complete");
                        Toast.makeText(Input_Code.this, "Проверка завершена", Toast.LENGTH_SHORT).show();
                        break;

                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        };
        hotelRef.addListenerForSingleValueEvent(eventListener);
    }

    public void CodeInputTwo() {

        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        final DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        final DatabaseReference hotelRef = rootRef.child("Codes_Cab_Two");
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        final String prefics = editText5.getText().toString();
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String codes = ds.child("codes").getValue(String.class);
                    String stroka = editText.getText().toString();
                    if (codes.contains(stroka) == true) {
                        String money = preferences.getString("CASE_ONE", "");
                        int first = Integer.parseInt(money);
                        int last = first - 1;
                        String result = String.valueOf(last);
                        editor.putString("CASE_ONE", result);
                        editor.apply();
                        databaseReference.child("Codes_Cab_Two").child(prefics).child("codes").setValue("complete");
                        Toast.makeText(Input_Code.this, "Проверка завершена", Toast.LENGTH_SHORT).show();
                        break;

                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        };
        hotelRef.addListenerForSingleValueEvent(eventListener);

    }

    public void CodeInputThree() {

        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        Toast.makeText(this, "Ничего не делайте мы выполняем проверку", Toast.LENGTH_SHORT).show();
        Toast.makeText(this, "По окончании проверки мы оповестим вас ", Toast.LENGTH_SHORT).show();
        final DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        final DatabaseReference hotelRef = rootRef.child("Codes_Cab_Three");
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        final String prefics = editText5.getText().toString();
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    String codes = ds.child("codes").getValue(String.class);
                    String stroka = editText.getText().toString();
                    if (codes.contains(stroka) == true) {
                        String money = preferences.getString("CASE_ONE", "");
                        int first = Integer.parseInt(money);
                        int last = first - 1;
                        String result = String.valueOf(last);
                        editor.putString("CASE_ONE", result);
                        editor.apply();
                        databaseReference.child("Codes_Cab_Three").child(prefics).child("codes").setValue("complete");
                        Toast.makeText(Input_Code.this, "Проверка завершена", Toast.LENGTH_SHORT).show();
                        break;

                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        };
        hotelRef.addListenerForSingleValueEvent(eventListener);

    }

}


