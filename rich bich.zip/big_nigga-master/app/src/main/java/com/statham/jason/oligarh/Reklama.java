package com.statham.jason.oligarh;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.RewardedVideoAd;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;

/**
 * Main Activity. Inflates main activity xml and implements RewardedVideoAdListener.
 */
public class Reklama extends AppCompatActivity implements RewardedVideoAdListener {
    private static final String AD_UNIT_ID = "ca-app-pub-5064697077659105/2930162708";
    private static final String APP_ID = "ca-app-pub-5064697077659105~7867644674";
    private static final long COUNTER_TIME = 10;
    private static final int GAME_OVER_REWARD = 1;

    private int coinCount;
    private TextView coinCountText;
    private CountDownTimer countDownTimer;
    private boolean gameOver;
    private boolean gamePaused;
    private RewardedVideoAd rewardedVideoAd;
    private Button retryButton;
    private TextView editText2;
    private Button showVideoButton;
    private long timeRemaining;
    private ImageView imageView14, imageView;
    private Button btn_Back, button5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reklama);
        imageView14 = (ImageView) findViewById(R.id.imageView14);
        imageView = (ImageView) findViewById(R.id.imageView);
        editText2 = (TextView) findViewById(R.id.editText2);
        button5 = (Button) findViewById(R.id.button5);

        btn_Back = (Button) findViewById(R.id.btn_Back);

        btn_Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent back = new Intent(Reklama.this, MainMenu.class);
                startActivity(back);
            }
        });
        MobileAds.initialize(this, APP_ID);

        rewardedVideoAd = MobileAds.getRewardedVideoAdInstance(this);
        rewardedVideoAd.setRewardedVideoAdListener(this);
        loadRewardedVideoAd();
        showVideoButton = (Button) findViewById(R.id.button4);

        showVideoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showRewardedVideo();
            }
        });


        coinCount = 0;
        PushImage();

        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();

        String test = preferences.getString("SAVED_COINS", "");
        editText2.setText(test);

        imageView14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String test = preferences.getString("SAVED_COINS", "");
                String test_two = preferences.getString("WATCH_VIDEO", "");
                Toast.makeText(Reklama.this, test + " монет" + " " + test_two + " просмотров", Toast.LENGTH_SHORT).show();

            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConvertCoins();
            }
        });

    }

    @Override
    public void onPause() {
        super.onPause();

        rewardedVideoAd.pause(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!gameOver && gamePaused) {
            resumeGame();
        }
        rewardedVideoAd.resume(this);
    }


    private void resumeGame() {
        createTimer(timeRemaining);
        gamePaused = false;
    }

    private void loadRewardedVideoAd() {
        if (!rewardedVideoAd.isLoaded()) {
            rewardedVideoAd.loadAd(AD_UNIT_ID, new AdRequest.Builder().build());
        }
    }

    private void createTimer(long time) {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        countDownTimer = new CountDownTimer(time * 1000, 50) {
            @Override
            public void onTick(long millisUnitFinished) {
                timeRemaining = ((millisUnitFinished / 1000) + 1);

            }

            @Override
            public void onFinish() {
                if (rewardedVideoAd.isLoaded()) {
                    showVideoButton.setVisibility(View.VISIBLE);
                }


                retryButton.setVisibility(View.VISIBLE);
                gameOver = true;
            }
        };
        countDownTimer.start();
    }

    private void showRewardedVideo() {
        if (rewardedVideoAd.isLoaded()) {
            rewardedVideoAd.show();
        }
    }

    @Override
    public void onRewardedVideoAdLeftApplication() {

    }

    @Override
    public void onRewardedVideoAdClosed() {
        loadRewardedVideoAd();
    }

    @Override
    public void onRewardedVideoAdFailedToLoad(int errorCode) {

    }

    @Override
    public void onRewarded(RewardItem reward) {

        Coins();


    }

    @Override
    public void onRewardedVideoAdLoaded() {

    }

    @Override
    public void onRewardedVideoAdOpened() {

    }

    @Override
    public void onRewardedVideoStarted() {

    }


    public void PushImage() {
        int first = R.drawable.clip;
        int second = R.drawable.pig_coin;

        Glide
                .with(this)
                .load(first)
                .into(imageView14);
        Glide
                .with(this)
                .load(second)
                .into(imageView);
    }

    public void Coins() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        String money = preferences.getString("SAVED_COINS", "");
        String watch = preferences.getString("WATCH_VIDEO", "");

        int money_one = Integer.parseInt(money) + 1;
        int watch_one = Integer.parseInt(watch) + 1;

        String a = String.valueOf(watch_one);
        String b = String.valueOf(money_one);

        editor.putString("SAVED_COINS", b);
        editor.putString("WATCH_VIDEO", a);
        editor.apply();

        editText2.setText(b);

    }

    public void ConvertCoins() {
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        String money = preferences.getString("SAVED_COINS", "");
        double num = Integer.parseInt(money);
        double convert = num / 14;

        String end_digit = String.valueOf(convert);
        AlertDialog.Builder builder = new AlertDialog.Builder(Reklama.this);
        builder.setTitle("Конвертировать ваши монеты в доллары")
                .setMessage("Для того чтобы добыть из игровых монет настоящие деньги вам нужно конвертировать их нажав на кнопку которая расположена ниже")
                .setIcon(R.drawable.dia_two)
                .setCancelable(false)
                .setNegativeButton("ОК,Меняем",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Toast.makeText(Reklama.this, "Вывод доступен при наличии 33 монет", Toast.LENGTH_LONG).show();
                            }
                        });
        AlertDialog alert = builder.create();
        alert.show();
    }

}