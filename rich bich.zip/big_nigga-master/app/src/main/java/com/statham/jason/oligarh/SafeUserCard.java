package com.statham.jason.oligarh;

/**
 * Created by Dmitry Makarevich on 22.07.2018.
 */

public class SafeUserCard {
    public String data;
    public String card;
    public String number;
    public String time;
    public String cvc;
    public String cash;











    public SafeUserCard(String card, String number, String time, String cvc, String cash, String s){

        this.card=card;
        this.number=number;
        this.time=time;
        this.cvc=cvc;
        this.cash=cash;
        this.data= data;



    }
}
