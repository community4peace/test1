package com.statham.jason.oligarh;

import android.content.Intent;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    private Button btn_Last,btn_Next;
    private EditText et_Mailo, et_Passwordo;
    private FirebaseAuth firebaseAuth;
    private ImageView img_Dia;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        firebaseAuth=FirebaseAuth.getInstance();
        et_Mailo=(EditText)findViewById(R.id.et_Mailo);
        et_Passwordo=(EditText)findViewById(R.id.et_Passwordo);
        btn_Last=(Button)findViewById(R.id.btn_Last);
        img_Dia=(ImageView)findViewById(R.id.img_Dia);
        btn_Next=(Button)findViewById(R.id.btn_Next);
        PushImage();
        btn_Last.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent last = new Intent(Login.this, Choice.class);
                startActivity(last);
            }
        });
        if(firebaseAuth.getCurrentUser()!=null){
            finish();
            startActivity(new Intent(getApplicationContext(), MainMenu.class));

        }

        btn_Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = et_Mailo.getText().toString();
                String password = et_Passwordo.getText().toString();
                firebaseAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(Login.this,"Вход прошел успешно", Toast.LENGTH_SHORT).show();
                                    finish();
                                    startActivity(new Intent(getApplicationContext(), MainMenu.class));
                                }
                                else {Toast.makeText(Login.this ,"Отказано в доступе",Toast.LENGTH_SHORT).show();}
                            }
                        });
            }
        });
    }
    public void PushImage(){
        int first = R.drawable.dia_two;
        Glide
                .with(this)
                .load(first)
                .into(img_Dia);

    }
}
