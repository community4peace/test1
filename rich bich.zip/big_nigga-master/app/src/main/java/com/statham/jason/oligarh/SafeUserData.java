package com.statham.jason.oligarh;

/**
 * Created by Dmitry Makarevich on 14.07.2018.
 */

public class SafeUserData {
    public String name;
    public String surname;
    public String mail;
    public String pasword;
    public String telephone;
    public String codes;









    public SafeUserData(String name, String surname, String mail, String pasword, String telephone){

        this.name=name;
        this.surname=surname;
        this.mail=mail;
        this.pasword=pasword;
        this.telephone=telephone;
        this.codes=codes;


    }

    public SafeUserData(String codes) {
        this.codes=codes;
    }
}