package com.statham.jason.oligarh;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

public class Choice extends AppCompatActivity {
    private Button btn_Login, btn_Registration;
    private ImageView img_diaTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);
        img_diaTwo = (ImageView) findViewById(R.id.img_DiaTwo);
        btn_Login = (Button) findViewById(R.id.btn_Login);
        btn_Registration = (Button) findViewById(R.id.btn_Registration);
        PushImage();
        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(Choice.this, Login.class);
                startActivity(login);
            }
        });
        btn_Registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
                final SharedPreferences.Editor editor = preferences.edit();
                String money = preferences.getString("NO_NAEB", "");
                String test = "123";
                try{
                if (money.contains(test) == true) {
                    Toast.makeText(Choice.this, "Вы уже зарегистрированы и пытаетесь нас обмануть , мы выключаем вам кнопку", Toast.LENGTH_LONG).show();
                    btn_Registration.setVisibility(View.INVISIBLE);
                    Toast.makeText(Choice.this, "Войдите в свой ранее зарегистрированный аккаунт", Toast.LENGTH_LONG).show();
                }
                else {
                    Intent registration = new Intent(Choice.this, Registration.class);
                    startActivity(registration);
                }}catch (NullPointerException e){ Intent registration = new Intent(Choice.this, Registration.class);
                    startActivity(registration);}
            }
        });

    }

    public void PushImage() {
        int first = R.drawable.dia_two;
        Glide
                .with(this)
                .load(first)
                .into(img_diaTwo);

    }

}
