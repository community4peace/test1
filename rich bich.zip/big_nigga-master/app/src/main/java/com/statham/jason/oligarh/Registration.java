package com.statham.jason.oligarh;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;

public class Registration extends AppCompatActivity {
    private Button btn_Lasty, btn_Next, button2;
    private EditText et_Name, et_Surname, et_Mail, et_Mobile, et_Password, et_Repeat;
    private FirebaseAuth firebaseAuth;
    private ImageView img_Dia;
    private DatabaseReference databaseReference;
    public static final String APP_PREFERENCES_NAME = "NO_NAEB";
    public static final String CASE_ONE = "CASE_ONE";
    public static final String CASE_TWO = "CASE_TWO";
    public static final String CASE_THREE = "CASE_THREE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        firebaseAuth = FirebaseAuth.getInstance();
        btn_Lasty = (Button) findViewById(R.id.btn_Lasty);
        btn_Next = (Button) findViewById(R.id.btn_Next);
        button2 = (Button) findViewById(R.id.button2);
        img_Dia = (ImageView) findViewById(R.id.img_Dia);
        et_Name = (EditText) findViewById(R.id.et_Name);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        et_Surname = (EditText) findViewById(R.id.et_Surname);
        et_Mail = (EditText) findViewById(R.id.et_Mailo);
        et_Mobile = (EditText) findViewById(R.id.et_Mobile);
        et_Password = (EditText) findViewById(R.id.et_Password);
        et_Repeat = (EditText) findViewById(R.id.et_Repeat);
        PushImage();
        btn_Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent next = new Intent(Registration.this , MainMenu.class);
                //startActivity(next);
                String mail = et_Mail.getText().toString();
                String password = et_Password.getText().toString();
                String repeat = et_Repeat.getText().toString();
                if (password.equals(repeat) == true) {
                    firebaseAuth.createUserWithEmailAndPassword(mail, password)
                            .addOnCompleteListener(Registration.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(Registration.this, "Регистрация прошла успешно", Toast.LENGTH_SHORT).show();
                                        btn_Next.setVisibility(View.INVISIBLE);
                                        button2.setVisibility(View.VISIBLE);


                                    } else {
                                        Toast.makeText(Registration.this, "Регистрация провалена ,пароль должен быть не менее 6 символов", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                } else {
                    Toast.makeText(Registration.this, "Пароли не совпадают, проверьте корректность", Toast.LENGTH_SHORT).show();
                }

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SafeData();
                Intent nextt = new Intent(Registration.this, MainMenu.class);
                startActivity(nextt);
            }
        });
        btn_Lasty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lasst = new Intent(Registration.this, Choice.class);
                startActivity(lasst);
            }
        });


        String coins = "0";
        String video = "0";
        final SharedPreferences preferences = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);
        final SharedPreferences.Editor editor = preferences.edit();
        editor.putString("SAVED_COINS", coins);
        editor.putString("WATCH_VIDEO", video);
        editor.apply();

    }

    public void PushImage() {
        int first = R.drawable.dia_two;
        Glide
                .with(this)
                .load(first)
                .into(img_Dia);

    }


    private void SafeData() {
        String name = et_Name.getText().toString().trim();
        String surname = et_Surname.getText().toString().trim();
        String mail = et_Mail.getText().toString().trim();
        String pasword = et_Password.getText().toString().trim();
        String telephone = et_Mobile.getText().toString().trim();

        SafeUserData safeUserData = new SafeUserData(name, surname , mail , pasword , telephone);

        FirebaseUser user = firebaseAuth.getCurrentUser();
        assert user != null;
        String end = "Users/" + user.getUid();
        databaseReference.child(end).setValue(safeUserData);
        databaseReference.child("No_Drop").child("Code").child("codes").setValue("1");
        databaseReference.child("No_Drop").child("Code").child("drop").setValue("1");
        Toast.makeText(getApplicationContext(), "Теперь вы в игре", Toast.LENGTH_SHORT).show();
        Intent inty = new Intent(Registration.this, MainMenu.class);
        startActivity(inty);

        NoNaeb();
    }

    private void NoNaeb(){
        CharSequence date = DateFormat.format("MM/dd/yy", System.currentTimeMillis());
        String calendar = String.valueOf(date);
        String no = "123";
        String one="1";
        String two="0";
        String three="0";
        SharedPreferences pref;
        pref = getSharedPreferences("AUTHENTICATION_FILE_NAME", Context.MODE_WORLD_WRITEABLE);;
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(APP_PREFERENCES_NAME, no);
        editor.putString(CASE_ONE, one);
        editor.putString(CASE_TWO, two);
        editor.putString(CASE_THREE, three);
        editor.putString("CALENDAR", calendar);
        editor.apply();
    }



    }

